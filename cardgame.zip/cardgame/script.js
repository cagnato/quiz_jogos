const questions = {
    'game1': [
      {question: 'Pergunta 1 sobre Jogo 1', answers: ['Opção 1', 'Opção 2', 'Opção 3', 'Opção 4'], correct: 1},
      {question: 'Pergunta 2 sobre Jogo 1', answers: ['Opção 1', 'Opção 2', 'Opção 3', 'Opção 4'], correct: 2},
      // Adicione mais perguntas conforme necessário
    ],
    'game2': [
      // Perguntas para Jogo 2
    ],
    'game3': [
      // Perguntas para Jogo 3
    ],
  };
  
  let currentTheme = '';
  let currentQuestionIndex = 0;
  let score = 0;
  
  function startQuiz(theme) {
    currentTheme = theme;
    currentQuestionIndex = 0;
    score = 0;
    document.getElementById('theme-selection').style.display = 'none';
    document.getElementById('quiz-container').style.display = 'block';
    loadQuestion();
  }
  
  function loadQuestion() {
    const questionObj = questions[currentTheme][currentQuestionIndex];
    document.getElementById('quiz-title').innerText = `Quiz sobre ${currentTheme}`;
    document.getElementById('question').innerText = questionObj.question;
    const answerBtns = document.querySelectorAll('.answer-btn');
    answerBtns.forEach((btn, index) => {
      btn.innerText = questionObj.answers[index];
    });
  }
  
  function checkAnswer(answerIndex) {
    const questionObj = questions[currentTheme][currentQuestionIndex];
    if (answerIndex === questionObj.correct) {
      score++;
      document.getElementById('feedback').innerText = 'Correto!';
    } else {
      document.getElementById('feedback').innerText = 'Errado!';
    }
  }
  
  function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions[currentTheme].length) {
      loadQuestion();
    } else {
      endQuiz();
    }
  }
  
  function endQuiz() {
    document.getElementById('quiz-container').innerHTML = `<h2>Fim do Quiz</h2><p>Sua pontuação: ${score}</p>`;
  }
  